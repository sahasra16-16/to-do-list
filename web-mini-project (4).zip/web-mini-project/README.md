# WEB MINI PROJECT

A Pen created on CodePen.

Original URL: [https://codepen.io/radhika-pulupula-AP23110010125/pen/Jojapze](https://codepen.io/radhika-pulupula-AP23110010125/pen/Jojapze).

